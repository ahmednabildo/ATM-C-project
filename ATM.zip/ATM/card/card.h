#include "defines.h"
uint8_t getCardHolderName(ST_cardData_t *cardData);
uint8_t getCardExpiryDate(ST_cardData_t *cardData);
uint8_t getCardPAN(ST_cardData_t *cardData);
uint8_t getCardData(ST_cardData_t *cardData);
uint8_t Card_Confirm(ST_cardData_t *cardData , data_base database[n]);

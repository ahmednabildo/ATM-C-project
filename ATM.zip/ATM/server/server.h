#include "terminal/terminal.h"
uint8_t check_the_state(data_base data_base_);
void save_trans(ST_transaction_t *trans , ST_cardData_t *card , ST_terminalData_t *terminal , float new_balance , uint8_t status);